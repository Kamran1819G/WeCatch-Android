# WeCatch-Android

## WeCatch Android Version
---
### 最新版本 (Newest Version): V4.3.7
---
* Old versions will no longer work after 12/3/2020
* 舊版本將於 12/3/2020 失效

特別感謝 (Special shoutout):

* **PGO-WeCatch-Android** - Thanks for the hard work.
https://github.com/kaiyan910/PGO-WeCatch-Android
